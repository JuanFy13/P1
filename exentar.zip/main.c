#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NUM_NEUMATICOS 4
int lectura;

// Función que simula la lectura de datos del sensor de presión de neumáticos
void leerPresionNeumaticos(int* arregloPresiones) {
    int i;
    lectura=1;
    srand(time(NULL)); // Inicializar la semilla aleatoria

    for (i = 0; i < NUM_NEUMATICOS; i++) {
        arregloPresiones[i] = rand() % 50 + 20; // Generar un número aleatorio entre 20 y 70
    }
}

// Función que evalúa la presión de los neumáticos y devuelve un warning si hay alguna llanta fuera del rango
void evaluarPresion(int* arregloPresiones) {
    int i;
    int presionMinima, presionMaxima;
    char tipoAuto;

    printf("Ingrese el tipo de auto (a, b o c): ");
    scanf(" %c", &tipoAuto);

    switch (tipoAuto) {
        case 'a':
            presionMinima = 30;
            presionMaxima = 35;
            break;
        case 'b':
            presionMinima = 32;
            presionMaxima = 35;
            break;
        case 'c':
            presionMinima = 35;
            presionMaxima = 45;
            break;
        default:
            printf("Tipo de auto inválido\n");
            return;
    }

    for (i = 0; i < NUM_NEUMATICOS; i++) {
        if (arregloPresiones[i] < presionMinima || arregloPresiones[i] > presionMaxima) {
            printf("El neumático %d está fuera del rango de presión recomendado\n", i + 1);
        }
    }

    printf("Estado de las llantas evaluado\n");
    }


// Función que imprime el estado de cada una de las llantas
void imprimirEstadoNeumaticos(int* arregloPresiones) {
    int i;

    printf("Estado de las llantas:\n");
    for (i = 0; i < NUM_NEUMATICOS; i++) {
        printf("Neumático %d: %d PSI\n", i + 1, arregloPresiones[i]);
    }
}

int main() {
    int presionesNeumaticos[NUM_NEUMATICOS];
    int opcion;
    lectura=0;
    do {
        printf("\nMenú:\n");
        printf("1. Leer presión de los neumáticos\n");
        printf("2. Evaluar presión de los neumáticos\n");
        printf("3. Imprimir estado de los neumáticos\n");
        printf("4. Salir\n");
        printf("Ingrese la opción deseada: ");
        scanf("%d", &opcion);

        switch (opcion) {
            case 1:
                leerPresionNeumaticos(presionesNeumaticos);
                system("clear");
                printf("Presiones tomada correctamente correctamente\n");
            break;
            case 2:
                system("clear");
                if(lectura==1)
                evaluarPresion(presionesNeumaticos);
                else
                printf("Error, lectura no realizada previamente\n");
                
            break;
            case 3:
                system("clear");
                if(lectura==1)
                imprimirEstadoNeumaticos(presionesNeumaticos);
                else
                printf("Error, lectura no realizada previamente\n");
                
            break;
            case 4:
                system("clear");
                printf("Fue un placer atenderle\n");
            break;
            default:
                system("clear");
                printf("Opción inválida\n");
            break;
        }
    } while (opcion != 4);

    return 0;
}