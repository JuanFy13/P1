/*#include <stdio.h>

int main()
   
    
   
{
    int num = 10 ;
    float decimal = 20.5;
    char letter = 'a';
    
    printf ("Juan Pablo Fierros Ramos \n 4775290 \n 24 - Mayo - 2023\n\n");
    printf("addres of int variable : %p\n",&num);
printf("addres of float variable : %p\n",&decimal);
printf("addres of letter variable : %p\n",&letter);

    return 0;
}

{
int dato =5;
int *ptrdato;

ptrdato = &dato;

printf ("Juan Pablo Fierros Ramos \n 4775290 \n 25 - Mayo - 2023\n\n");
printf ("direccion de dato : %p\n", &dato);
printf ("dato: %d\n",dato);
printf ("ptrdato: %p\n",ptrdato);

return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_NEUMATICOS 4

void leerPresionNeumaticos(int * arregloPresiones){
    int i;
    srand (time(NULL));
    for (i=0; i<NUM_NEUMATICOS; i++)
    {
        arregloPresiones[i]=rand()%50+20;
    }
}


int main()
{
  int presionesNeumaticos[NUM_NEUMATICOS];
  int i; 
  leerPresionNeumaticos(presionesNeumaticos);
  
  printf ("Juan Pablo Fierros Ramos \n 4775290 \n 26 - Mayo - 2023\n\n");
  printf("PRESIONES DE LOS NEUMATICOS");
  for(i=0; i<NUM_NEUMATICOS; i++)
  {
      printf("\nNeumatico %d: %d PSI",i+1,presionesNeumaticos[i]);
  }

    return 0;
}

#include <stdio.h>
#define TAMANO_ARREGLO 5

int main() {

int v[10];
int i, *p;

for (i=0; i < 10; i++) v[i] = i;
printf ("Juan Pablo Fierros Ramos \n 4775290 \n 29 - Mayo - 2023\n\n");
for (i=0; i < 10; i++) printf ("\n%d", v[i]);
p = v;
for (i=0; i < 10; i++) printf ("\n%d", *p++);

for (i=0; i < 10 ; i ++) printf ("\n%d",&*p++);
return 0; 
}*/

#include <stdio.h>

void main()

{
char cadena[20];
int longitud();
printf ("\nDame una cadena (maximo 20): ");
gets(cadena);
printf ("\nLa cadena %s mide %d ", cadena, longitud(cadena));
}
int longitud(char *s){
int l;
l = 0;
while (*s++ != '\0') l++;
return l;
}
