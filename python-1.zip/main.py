def main():
    c = ''
    x = 0
    y = 0.0
    Arreglo = [0] * 2
    print("PRACTICA 1\n Juan Pablo Fierros Ramos\n 4775290\n")
    print("TIPOS DE DATOS")
    print("CHAR")
    print("El tamaño en bytes de una variable char es:", c.__sizeof__())
    print("El tamaño en bits de una variable char es:", c.__sizeof__() * 8)
    print("El tamaño en nibbles de una variable char es:", c.__sizeof__() * 2)
    print("ENTERO")
    print("El tamaño en bytes de una variable int es:", x.__sizeof__())
    print("El tamaño en bits de una variable int es:", x.__sizeof__() * 8)
    print("El tamaño en nibbles de una variable int es:", x.__sizeof__() * 2)
    print("DOUBLE")
    print("El tamaño en bytes de una variable double es:", y.__sizeof__())
    print("El tamaño en bits de una variable double es:", y.__sizeof__() * 8)
    print("El tamaño en nibbles de una variable double es:", y.__sizeof__() * 2)
    print("ARREGLO")
    print("El tamaño en bytes de un arreglo es:", Arreglo.__sizeof__())
    print("El tamaño en bits de un arreglo es:", Arreglo.__sizeof__() * 8)
    print("El tamaño en nibbles de un arreglo es:", Arreglo.__sizeof__() * 2)

if __name__ == "__main__":
    main()





