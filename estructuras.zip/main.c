#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct personas{
    char name [20];
    char sex[2];
    int age;
};
struct personas p1;//estructura global

void llenar ()//funcion para llenar los datos
    {
     printf("Ingresa el nombre: ");
     scanf("%s",p1.name);
     printf("Ingresa el genero (M o F):");
     scanf("%s",p1.sex);
     printf("Inresa la edad:");
     scanf("%d",&p1.age);
    }
void imprimir ()//funcion para imprimir los datos
    {
        system("clear");
        printf("Nombre: %s\nGenero: %s\nEdad: %d\n",p1.name,p1.sex,p1.age);
    }
void mod ()//funcion para modificar los datos
    {
    int decision;
    int modificar;
    system("clear");
    printf("Los siguientes datos son correctos?\n");
    printf("Nombre: %s\nGenero: %s\nEdad: %d\n",p1.name,p1.sex,p1.age);
    printf("Si desea modificar un dato presione 0\n");
    scanf("%d",&decision);
    while(decision==0)
    {
    printf("Para modificar el nombre presione 1\nPara modificar el genero presiona 2\nPara modificar la edad presiona 3\n");
    scanf("%d",&modificar);
        if(modificar==1)
            {
            printf("Ingresa el nuevo nombre: ");
            scanf("%s",p1.name);          
            }
        else if(modificar==2)
        {
            printf("Ingresa el nuevo genero (M o F):");
            scanf("%s",p1.sex);   
        }
        else if(modificar==3)
        {
            printf("Inresa la nueva edad:");
            scanf("%d",&p1.age);
        }
    system("clear");
    printf("Nombre: %s\nGenero: %s\nEdad: %d\n",p1.name,p1.sex,p1.age);
    printf("Si desea modificar otro dato presione 0\n");
    scanf("%d",&decision);
    }
    }
    void decimas()
    {
        system("clear");
        printf("Juan Pablo Fierros Ramos \n 4775290 \n 01 - Junio - 2023\n");
        printf("Nombre: %s\nGenero: %s\nEdad: %d\n",p1.name,p1.sex,p1.age);
    }
int main()
{
    llenar();
    mod ();
    imprimir();
    decimas();
    return 0;
}