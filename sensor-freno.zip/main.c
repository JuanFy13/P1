#include <stdio.h>
#include <stdlib.h>

#define MAX_SENSORES 5

struct SensorFreno {
    int id;
    float presion;
    char ubicacion[20];
};

void inicializarSensores(struct SensorFreno *sensores) {
    for (int i = 0; i < MAX_SENSORES; i++) {
        printf("Ingrese el ID del sensor %d: ", i + 1);
        scanf("%d", &(sensores[i].id));

        printf("Ingrese la presión del sensor %d: ", i + 1);
        scanf("%f", &(sensores[i].presion));

        printf("Ingrese la ubicación del sensor %d: ", i + 1);
        scanf(" %[^\n]s", sensores[i].ubicacion);
    }
}

void imprimirSensores(const struct SensorFreno *sensores) {
    for (int i = 0; i < MAX_SENSORES; i++) {
        printf("Sensor de freno ID: %d\n", sensores[i].id);
        printf("Presión del sensor: %.2f\n", sensores[i].presion);
        printf("Ubicación del sensor: %s\n\n", sensores[i].ubicacion);
    }
}

int main() {
    struct SensorFreno sensores[MAX_SENSORES] = {
        {1, 30.5, "Delantero izquierdo"},
        {2, 28.3, "Delantero derecho"},
        {3, 31.2, "Trasero izquierdo"},
        {4, 29.8, "Trasero derecho"},
        {5, 27.6, "Freno de mano"}
    };

    int opcion;
    while (1) {
        printf("MENU:\n");
        printf("A) Imprimir arreglo de sensores\n");
        printf("B) Borrar arreglo de sensores\n");
        printf("C) Salir\n");
        printf("Ingrese una opción: ");
        scanf(" %c", &opcion);

        switch (opcion) {
            case 'A':
            case 'a':
                imprimirSensores(sensores);
                break;
            case 'B':
            case 'b':
                inicializarSensores(sensores);
                break;
            case 'C':
            case 'c':
                return 0;
            default:
                printf("Opción inválida. Intente nuevamente.\n");
                break;
        }
    }

    return 0;
}

